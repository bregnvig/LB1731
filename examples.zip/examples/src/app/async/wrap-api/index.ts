export * from './wrap-api.component';
