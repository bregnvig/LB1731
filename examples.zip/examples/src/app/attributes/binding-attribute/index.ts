export * from './binding-attribute.component';
