/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { BindingsAttributeComponent } from './bindings-attribute.component';

describe('Component: BindingsAttribute', () => {
  it('should create an instance', () => {
    let component = new BindingsAttributeComponent();
    expect(component).toBeTruthy();
  });
});
