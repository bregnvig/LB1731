/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { CaseStudyComponent } from './case-study.component';

describe('Component: CaseStudy', () => {
  it('should create an instance', () => {
    let component = new CaseStudyComponent();
    expect(component).toBeTruthy();
  });
});
