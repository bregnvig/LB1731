/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { PureComponent } from './pure.component';

describe('Component: Pure', () => {
  it('should create an instance', () => {
    let component = new PureComponent();
    expect(component).toBeTruthy();
  });
});
