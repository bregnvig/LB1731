export * from './pure.component';
