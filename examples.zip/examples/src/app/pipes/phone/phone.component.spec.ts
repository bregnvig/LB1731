/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { PhoneComponent } from './phone.component';

describe('Component: Phone', () => {
  it('should create an instance', () => {
    let component = new PhoneComponent();
    expect(component).toBeTruthy();
  });
});
