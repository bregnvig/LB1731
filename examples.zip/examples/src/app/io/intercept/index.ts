export * from './intercept.component';
