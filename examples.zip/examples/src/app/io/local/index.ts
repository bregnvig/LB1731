export * from './local.component';
