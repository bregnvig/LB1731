import { Component, OnInit } from '@angular/core';

import { StopwatchComponent } from '../stopwatch';

@Component({
  selector: 'app-local',
  templateUrl: './local.component.html',
  styleUrls: ['./local.component.css'],
})
export class LocalComponent {
}
