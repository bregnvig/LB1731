export * from './directly.component';
