import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-factory-provided-parent',
  templateUrl: './factory-provided-parent.component.html',
  styleUrls: ['./factory-provided-parent.component.css']
})
export class FactoryProvidedParentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
