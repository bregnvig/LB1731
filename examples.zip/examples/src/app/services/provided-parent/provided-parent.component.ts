import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provided-parent',
  templateUrl: './provided-parent.component.html',
  styleUrls: ['./provided-parent.component.css']
})
export class ProvidedParentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
