export * from './person-form-2.component';
