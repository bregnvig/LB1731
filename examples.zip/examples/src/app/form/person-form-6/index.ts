export * from './person-form-6.component';
