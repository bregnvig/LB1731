/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { PersonForm6Component } from './person-form-6.component';

describe('Component: PersonForm6', () => {
  it('should create an instance', () => {
    let component = new PersonForm6Component();
    expect(component).toBeTruthy();
  });
});
