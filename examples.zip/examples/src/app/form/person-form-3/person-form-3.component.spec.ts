/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { PersonForm3Component } from './person-form-3.component';

describe('Component: PersonForm3', () => {
  it('should create an instance', () => {
    let component = new PersonForm3Component();
    expect(component).toBeTruthy();
  });
});
