/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { PersonForm4Component } from './person-form-4.component';

describe('Component: PersonForm4', () => {
  it('should create an instance', () => {
    let component = new PersonForm4Component();
    expect(component).toBeTruthy();
  });
});
