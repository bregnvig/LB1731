/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { PersonForm5Component } from './person-form-5.component';

describe('Component: PersonForm5', () => {
  it('should create an instance', () => {
    let component = new PersonForm5Component();
    expect(component).toBeTruthy();
  });
});
