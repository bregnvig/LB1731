export * from './outer.component';
