/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { TwowayComponent } from './twoway.component';

describe('Component: Twoway', () => {
  it('should create an instance', () => {
    let component = new TwowayComponent();
    expect(component).toBeTruthy();
  });
});
