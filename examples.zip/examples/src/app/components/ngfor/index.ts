export * from './ngfor.component';
