/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { PropertyComponent } from './property.component';

describe('Component: Property', () => {
  it('should create an instance', () => {
    let component = new PropertyComponent();
    expect(component).toBeTruthy();
  });
});
