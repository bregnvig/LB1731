export * from './property.component';
