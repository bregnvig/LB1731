/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, inject } from '@angular/core/testing';
import { MenuComponent } from './menu.component';

describe('Component: Menu', () => {
  it('should create an instance', () => {
    let component = new MenuComponent();
    expect(component).toBeTruthy();
  });
});
